USE blood_donation_system;

-- DONORS (5 Users: ID 1-5)
INSERT INTO User (name, email, password, role, status) VALUES
('John Doe', 'john.doe@example.com', 'pass123', 'Donor', 'Active'),
('Jane Smith', 'jane.smith@example.com', 'pass123', 'Donor', 'Active'),
('Michael Brown', 'michael.b@example.com', 'pass123', 'Donor', 'Active'),
('Emily Davis', 'emily.d@example.com', 'pass123', 'Donor', 'Active'),
('Chris Wilson', 'chris.w@example.com', 'pass123', 'Donor', 'Active');

INSERT INTO Donor (donor_id, blood_type, contact_number, eligibility_status) VALUES
(1, 'A+', '0123456789', 'Eligible'),
(2, 'O-', '0123456788', 'Eligible'),
(3, 'B+', '0123456787', 'Temporary Ban'),
(4, 'AB+', '0123456786', 'Eligible'),
(5, 'A-', '0123456785', 'Eligible');

-- EVENT ORGANIZERS (5 Users: ID 6-10)
INSERT INTO User (name, email, password, role, status) VALUES
('Alice Green', 'alice.g@example.com', 'pass123', 'Organizer', 'Active'),
('Bob White', 'bob.w@example.com', 'pass123', 'Organizer', 'Active'),
('Charlie Black', 'charlie.b@example.com', 'pass123', 'Organizer', 'Active'),
('David Grey', 'david.g@example.com', 'pass123', 'Organizer', 'Active'),
('Eve Blue', 'eve.b@example.com', 'pass123', 'Organizer', 'Active');

INSERT INTO EventOrganizer (organizer_id, organization_name, verification_status) VALUES
(6, 'Red Cross Local', 'Verified'),
(7, 'City Helpers', 'Verified'),
(8, 'Community Care', 'Verified'),
(9, 'Uni Students Club', 'Verified'),
(10, 'Health First', 'Verified');

-- HOSPITALS (6 Users: ID 11-16)
INSERT INTO User (name, email, password, role, status) VALUES
('A Hosp', 'a@hosp.com', 'pass123', 'Hospital', 'Active'),
('B Hosp', 'b@hosp.com', 'pass123', 'Hospital', 'Active'),
('C Hosp', 'c@hosp.com', 'pass123', 'Hospital', 'Pending'),
('D Hosp', 'd@hosp.com', 'pass123', 'Hospital', 'Pending'),
('E Hosp', 'e@hosp.com', 'pass123', 'Hospital', 'Pending'),
('F Hosp', 'f@hosp.com', 'pass123', 'Hospital', 'Active');

INSERT INTO Hospital (hospital_id, hospital_name, address, verification_status) VALUES
(11, 'A Hospital', '123 Main', 'Verified'),    -- Status 1
(12, 'B Medical Center', '456 Bunga', 'Suspended'), -- Status 2
(13, 'C Clinic', '789 Oak', 'Rejected'),         -- Status 3
(14, 'D', '100 Flower', 'Pending'),    -- Pending 1
(15, 'E', '200 Maple', 'Pending'),     -- Pending 2
(16, 'F', '300 Cedar', 'Pending');    -- Pending 3

-- ADMINS (5 Users: ID 17-21)
INSERT INTO User (name, email, password, role, status) VALUES
('A1', 'admin1@sys.com', 'pass123', 'Admin', 'Active'),
('A2', 'admin2@sys.com', 'pass123', 'Admin', 'Active'),
('A3', 'admin3@sys.com', 'pass123', 'Admin', 'Active'),
('A4', 'admin4@sys.com', 'pass123', 'Admin', 'Active'),
('A5', 'admin5@sys.com', 'pass123', 'Admin', 'Active');


-- EVENTS

INSERT INTO Event (event_name, event_date, event_time, venue, capacity, status, organizer_id, `desc`) VALUES
-- Organizer 6
('Event A', '2023-12-01', '09:00', 'Hall 1A', 100, 'Completed', 6, 'Event A Blood Donation'),
('Event B', '2024-05-20', '10:00', 'Hall 2A', 50, 'Upcoming', 6, 'Event B Blood Donation'),
('Event C', '2023-11-15', '14:00', 'Hall 3A', 30, 'Cancelled', 6, NULL),

-- Organizer 7
('Event D', '2023-10-10', '08:00', 'Hall 4A', 200, 'Completed', 7, 'Event D Blood Donation'),
('Event E', '2024-04-15', '09:00', 'Hall 5A', 150, 'Upcoming', 7, NULL),
('Event F', '2023-12-25', '10:00', 'Hall 6A', 40, 'Cancelled', 7, 'Event F Blood Donation'),

-- Organizer 8
('Event G', '2023-09-01', '11:00', 'Hall 7A', 80, 'Completed', 8, 'Event G Blood Donation'),
('Event H', '2024-06-01', '08:30', 'Hall 8A', 300, 'Upcoming', 8, 'Event H Blood Donation'),
('Event I', '2023-08-05', '16:00', 'Hall 9A', 20, 'Cancelled', 8, NULL),

-- Organizer 9
('Event J', '2023-07-07', '09:00', 'Hall 10A', 120, 'Completed', 9, 'Event J Blood Donation'),
('Event K', '2024-05-10', '10:00', 'Hall 11A', 60, 'Upcoming', 9, 'Event K Blood Donation'),
('Event L', '2023-06-01', '19:00', 'Hall 12A', 50, 'Cancelled', 9, NULL),

-- Organizer 10
('Event M', '2023-05-05', '07:00', 'Hall 13A', 500, 'Completed', 10, NULL),
('Event N', '2024-05-25', '12:00', 'Hall 14A', 20, 'Upcoming', 10, 'Event N Blood Donation'),
('Event O', '2023-04-01', '10:00', 'Hall 15A', 100, 'Cancelled', 10, 'Event O Blood Donation');


-- POPULATE BLOOD INVENTORY
INSERT INTO BloodInventory (hospital_id, blood_type, quantity, status) VALUES
(11, 'A+', 50, 'Normal'),
(11, 'A-', 10, 'Low'),
(11, 'B+', 45, 'Normal'),
(11, 'B-', 5, 'Critical'),
(12, 'AB+', 20, 'Normal'),
(12, 'AB-', 8, 'Low'),
(11, 'O+', 100, 'Normal'),
(11, 'O-', 15, 'Low');

-- 4. POPULATE REGISTRATION REQUESTS (Optional Context)
INSERT INTO RegistrationRequest (hospital_id, documents, status, submit_date, rejection_reason) VALUES
(13, 'doc_link_13.pdf', 'Rejected', '2023-12-01', 'Invalid License'),
(14, 'doc_link_14.pdf', 'Pending', '2024-01-10', NULL),
(15, 'doc_link_15.pdf', 'Pending', '2024-01-12', NULL),
(16, 'doc_link_16.pdf', 'Pending', '2024-01-15', NULL);
