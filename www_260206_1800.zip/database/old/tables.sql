-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.4.3 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for blood_donation_system
CREATE DATABASE IF NOT EXISTS `blood_donation_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `blood_donation_system`;

-- Dumping structure for table blood_donation_system.appointment
CREATE TABLE IF NOT EXISTS `appointment` (
  `appointment_id` int unsigned NOT NULL AUTO_INCREMENT,
  `donor_id` int unsigned NOT NULL,
  `event_id` int unsigned NOT NULL,
  `appointment_date` date NOT NULL,
  `time_slot` varchar(10) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `donor_id` (`donor_id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donor` (`donor_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.bloodinventory
CREATE TABLE IF NOT EXISTS `bloodinventory` (
  `inventory_id` int unsigned NOT NULL AUTO_INCREMENT,
  `hospital_id` int unsigned NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '0',
  `status` enum('Normal','Low','Critical') NOT NULL,
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`inventory_id`),
  KEY `hospital_id` (`hospital_id`),
  CONSTRAINT `bloodinventory_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.donor
CREATE TABLE IF NOT EXISTS `donor` (
  `donor_id` int unsigned NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `eligibility_status` varchar(15) NOT NULL,
  PRIMARY KEY (`donor_id`),
  CONSTRAINT `donor_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.event
CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int unsigned NOT NULL AUTO_INCREMENT,
  `event_name` varchar(50) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(10) NOT NULL,
  `venue` varchar(100) NOT NULL,
  `capacity` int unsigned NOT NULL,
  `status` varchar(15) NOT NULL,
  `organizer_id` int unsigned NOT NULL,
  `desc` text,
  PRIMARY KEY (`event_id`),
  KEY `organizer_id` (`organizer_id`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`organizer_id`) REFERENCES `eventorganizer` (`organizer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.eventorganizer
CREATE TABLE IF NOT EXISTS `eventorganizer` (
  `organizer_id` int unsigned NOT NULL,
  `organization_name` varchar(50) NOT NULL,
  `verification_status` varchar(15) NOT NULL,
  PRIMARY KEY (`organizer_id`),
  CONSTRAINT `eventorganizer_ibfk_1` FOREIGN KEY (`organizer_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.hospital
CREATE TABLE IF NOT EXISTS `hospital` (
  `hospital_id` int unsigned NOT NULL,
  `hospital_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `verification_status` varchar(15) NOT NULL,
  PRIMARY KEY (`hospital_id`),
  CONSTRAINT `hospital_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.notification
CREATE TABLE IF NOT EXISTS `notification` (
  `notification_id` int unsigned NOT NULL AUTO_INCREMENT,
  `message` varchar(150) NOT NULL,
  `channel` varchar(15) NOT NULL,
  `status` varchar(15) NOT NULL,
  `sent_date` date NOT NULL,
  `donor_id` int unsigned NOT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `donor_id` (`donor_id`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.registrationrequest
CREATE TABLE IF NOT EXISTS `registrationrequest` (
  `request_id` int unsigned NOT NULL AUTO_INCREMENT,
  `hospital_id` int unsigned NOT NULL,
  `documents` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `submit_date` date NOT NULL,
  `rejection_reason` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `hospital_id` (`hospital_id`),
  CONSTRAINT `registrationrequest_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.report
CREATE TABLE IF NOT EXISTS `report` (
  `report_id` int unsigned NOT NULL AUTO_INCREMENT,
  `report_type` varchar(20) NOT NULL,
  `generated_by` int unsigned NOT NULL,
  `generated_date` date NOT NULL,
  `export_format` varchar(10) NOT NULL,
  PRIMARY KEY (`report_id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `report_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table blood_donation_system.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` varchar(15) DEFAULT 'Active',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
