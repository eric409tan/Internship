-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.4.3 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for blood_donation_system
CREATE DATABASE IF NOT EXISTS `blood_donation_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `blood_donation_system`;

-- Dumping structure for table blood_donation_system.appointment
CREATE TABLE IF NOT EXISTS `appointment` (
  `appointment_id` int unsigned NOT NULL AUTO_INCREMENT,
  `donor_id` int unsigned NOT NULL,
  `event_id` int unsigned NOT NULL,
  `appointment_date` date NOT NULL,
  `time_slot` varchar(10) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `donor_id` (`donor_id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donor` (`donor_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.appointment: ~0 rows (approximately)
DELETE FROM `appointment`;
INSERT INTO `appointment` (`appointment_id`, `donor_id`, `event_id`, `appointment_date`, `time_slot`, `status`) VALUES
	(3, 5, 11, '2024-05-10', '10:00', 'Pending'),
	(5, 5, 14, '2024-05-25', '12:00', 'Completed'),
	(6, 1, 1, '2023-12-01', '09:00', 'Completed'),
	(7, 2, 1, '2023-12-01', '09:15', 'Completed'),
	(8, 3, 1, '2023-12-01', '09:30', 'Completed'),
	(9, 4, 1, '2023-12-01', '09:45', 'Completed'),
	(10, 5, 1, '2023-12-01', '10:00', 'Completed'),
	(11, 1, 1, '2023-12-01', '10:15', 'Completed'),
	(12, 2, 1, '2023-12-01', '10:30', 'Completed'),
	(13, 3, 1, '2023-12-01', '10:45', 'Completed'),
	(14, 4, 1, '2023-12-01', '11:00', 'Completed'),
	(15, 5, 1, '2023-12-01', '11:15', 'Completed'),
	(16, 1, 1, '2023-12-01', '11:30', 'Completed'),
	(17, 2, 4, '2023-10-10', '08:00', 'Completed'),
	(18, 3, 4, '2023-10-10', '08:15', 'Completed'),
	(19, 4, 4, '2023-10-10', '08:30', 'Completed'),
	(20, 5, 4, '2023-10-10', '08:45', 'Completed'),
	(21, 1, 4, '2023-10-10', '09:00', 'Completed'),
	(22, 2, 4, '2023-10-10', '09:15', 'Completed'),
	(23, 3, 4, '2023-10-10', '09:30', 'Completed'),
	(24, 4, 4, '2023-10-10', '09:45', 'Completed'),
	(25, 5, 4, '2023-10-10', '10:00', 'Completed'),
	(26, 1, 4, '2023-10-10', '10:15', 'Completed'),
	(27, 2, 4, '2023-10-10', '10:30', 'Completed'),
	(28, 3, 7, '2023-09-01', '11:00', 'Completed'),
	(29, 4, 7, '2023-09-01', '11:15', 'Completed'),
	(30, 5, 7, '2023-09-01', '11:30', 'Completed'),
	(31, 1, 7, '2023-09-01', '11:45', 'Completed'),
	(32, 2, 7, '2023-09-01', '12:00', 'Completed'),
	(33, 3, 7, '2023-09-01', '12:15', 'Completed'),
	(34, 4, 7, '2023-09-01', '12:30', 'Completed'),
	(35, 5, 7, '2023-09-01', '12:45', 'Completed'),
	(36, 1, 7, '2023-09-01', '13:00', 'Completed'),
	(37, 2, 7, '2023-09-01', '13:15', 'Completed'),
	(38, 3, 7, '2023-09-01', '13:30', 'Completed'),
	(39, 4, 10, '2023-07-07', '09:00', 'Completed'),
	(40, 5, 10, '2023-07-07', '09:15', 'Completed'),
	(41, 1, 10, '2023-07-07', '09:30', 'Completed'),
	(42, 2, 10, '2023-07-07', '09:45', 'Completed'),
	(43, 3, 10, '2023-07-07', '10:00', 'Completed'),
	(44, 4, 10, '2023-07-07', '10:15', 'Completed'),
	(45, 5, 10, '2023-07-07', '10:30', 'Completed'),
	(46, 1, 10, '2023-07-07', '10:45', 'Completed'),
	(47, 2, 10, '2023-07-07', '11:00', 'Completed'),
	(48, 3, 10, '2023-07-07', '11:15', 'Completed'),
	(49, 4, 10, '2023-07-07', '11:30', 'Completed'),
	(50, 5, 13, '2023-05-05', '07:00', 'Completed'),
	(51, 1, 13, '2023-05-05', '07:15', 'Completed'),
	(52, 2, 13, '2023-05-05', '07:30', 'Completed'),
	(53, 3, 13, '2026-05-05', '07:45', 'Completed'),
	(54, 4, 13, '2023-05-05', '08:00', 'Completed'),
	(55, 5, 13, '2023-05-05', '08:15', 'Completed'),
	(56, 1, 13, '2023-05-05', '08:30', 'Completed'),
	(57, 2, 13, '2023-05-05', '08:45', 'Completed'),
	(58, 3, 13, '2023-05-05', '09:00', 'Completed'),
	(59, 4, 13, '2023-05-05', '09:15', 'Completed'),
	(60, 5, 13, '2023-05-05', '09:30', 'Completed'),
	(61, 1, 13, '2023-05-05', '09:45', 'Completed'),
	(63, 5, 5, '2024-04-15', '09:00', 'Pending');

-- Dumping structure for table blood_donation_system.bloodinventory
CREATE TABLE IF NOT EXISTS `bloodinventory` (
  `inventory_id` int unsigned NOT NULL AUTO_INCREMENT,
  `hospital_id` int unsigned NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '0',
  `status` enum('Normal','Low','Critical') NOT NULL,
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`inventory_id`),
  KEY `hospital_id` (`hospital_id`),
  CONSTRAINT `bloodinventory_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.bloodinventory: ~8 rows (approximately)
DELETE FROM `bloodinventory`;
INSERT INTO `bloodinventory` (`inventory_id`, `hospital_id`, `blood_type`, `quantity`, `status`, `last_updated`) VALUES
	(1, 11, 'A+', 50, 'Normal', '2026-02-02 01:29:24'),
	(2, 11, 'A-', 10, 'Low', '2026-02-02 01:29:24'),
	(3, 11, 'B+', 45, 'Normal', '2026-02-02 01:29:24'),
	(4, 11, 'B-', 5, 'Critical', '2026-02-02 01:29:24'),
	(5, 12, 'AB+', 20, 'Normal', '2026-02-02 01:29:24'),
	(6, 12, 'AB-', 8, 'Low', '2026-02-02 01:29:24'),
	(7, 11, 'O+', 100, 'Normal', '2026-02-02 01:29:24'),
	(8, 11, 'O-', 15, 'Low', '2026-02-02 01:29:24');

-- Dumping structure for table blood_donation_system.donor
CREATE TABLE IF NOT EXISTS `donor` (
  `donor_id` int unsigned NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `eligibility_status` varchar(15) NOT NULL,
  PRIMARY KEY (`donor_id`),
  CONSTRAINT `donor_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.donor: ~5 rows (approximately)
DELETE FROM `donor`;
INSERT INTO `donor` (`donor_id`, `blood_type`, `contact_number`, `eligibility_status`) VALUES
	(1, 'A+', '0123456789', 'Eligible'),
	(2, 'O-', '0123456788', 'Eligible'),
	(3, 'B+', '0123456787', 'Temporary Ban'),
	(4, 'AB+', '0123456786', 'Eligible'),
	(5, 'A-', '0123456785', 'Eligible');

-- Dumping structure for table blood_donation_system.event
CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int unsigned NOT NULL AUTO_INCREMENT,
  `event_name` varchar(50) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(10) NOT NULL,
  `venue` varchar(100) NOT NULL,
  `capacity` int unsigned NOT NULL,
  `status` varchar(15) NOT NULL,
  `organizer_id` int unsigned NOT NULL,
  `desc` text,
  PRIMARY KEY (`event_id`),
  KEY `organizer_id` (`organizer_id`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`organizer_id`) REFERENCES `eventorganizer` (`organizer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.event: ~15 rows (approximately)
DELETE FROM `event`;
INSERT INTO `event` (`event_id`, `event_name`, `event_date`, `event_time`, `venue`, `capacity`, `status`, `organizer_id`, `desc`) VALUES
	(1, 'Event A', '2023-12-01', '09:00', 'Hall 1A', 100, 'Completed', 6, 'Event A Blood Donation'),
	(2, 'Event B', '2024-05-20', '10:00', 'Hall 2A', 50, 'Upcoming', 6, 'Event B Blood Donation'),
	(3, 'Event C', '2023-11-15', '14:00', 'Hall 3A', 30, 'Cancelled', 6, NULL),
	(4, 'Event D', '2023-10-10', '08:00', 'Hall 4A', 200, 'Completed', 7, 'Event D Blood Donation'),
	(5, 'Event E', '2024-04-15', '09:00', 'Hall 5A', 150, 'Upcoming', 7, NULL),
	(6, 'Event F', '2023-12-25', '10:00', 'Hall 6A', 40, 'Cancelled', 7, 'Event F Blood Donation'),
	(7, 'Event G', '2023-09-01', '11:00', 'Hall 7A', 80, 'Completed', 8, 'Event G Blood Donation'),
	(8, 'Event H', '2024-06-01', '08:30', 'Hall 8A', 300, 'Cancelled', 8, 'Event H Blood Donation'),
	(9, 'Event I', '2023-08-05', '16:00', 'Hall 9A', 20, 'Cancelled', 8, NULL),
	(10, 'Event J', '2023-07-07', '09:00', 'Hall 10A', 120, 'Completed', 9, 'Event J Blood Donation'),
	(11, 'Event K', '2024-05-10', '10:00', 'Hall 11A', 60, 'Upcoming', 9, 'Event K Blood Donation'),
	(12, 'Event L', '2023-06-01', '19:00', 'Hall 12A', 50, 'Cancelled', 9, NULL),
	(13, 'Event M', '2023-05-05', '07:00', 'Hall 13A', 500, 'Completed', 10, NULL),
	(14, 'Event N', '2024-05-25', '12:00', 'Hall 14A', 20, 'Upcoming', 10, 'Event N Blood Donation'),
	(15, 'Event O', '2023-04-01', '10:00', 'Hall 15A', 100, 'Cancelled', 10, 'Event O Blood Donation');

-- Dumping structure for table blood_donation_system.eventorganizer
CREATE TABLE IF NOT EXISTS `eventorganizer` (
  `organizer_id` int unsigned NOT NULL,
  `organization_name` varchar(50) NOT NULL,
  `verification_status` varchar(15) NOT NULL,
  PRIMARY KEY (`organizer_id`),
  CONSTRAINT `eventorganizer_ibfk_1` FOREIGN KEY (`organizer_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.eventorganizer: ~5 rows (approximately)
DELETE FROM `eventorganizer`;
INSERT INTO `eventorganizer` (`organizer_id`, `organization_name`, `verification_status`) VALUES
	(6, 'Red Cross Local', 'Verified'),
	(7, 'City Helpers', 'Verified'),
	(8, 'Community Care', 'Verified'),
	(9, 'Uni Students Club', 'Verified'),
	(10, 'Health First', 'Verified');

-- Dumping structure for table blood_donation_system.hospital
CREATE TABLE IF NOT EXISTS `hospital` (
  `hospital_id` int unsigned NOT NULL,
  `hospital_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `verification_status` varchar(15) NOT NULL,
  PRIMARY KEY (`hospital_id`),
  CONSTRAINT `hospital_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.hospital: ~6 rows (approximately)
DELETE FROM `hospital`;
INSERT INTO `hospital` (`hospital_id`, `hospital_name`, `address`, `verification_status`) VALUES
	(11, 'A Hospital', '123 Main', 'Verified'),
	(12, 'B Medical Center', '456 Bunga', 'Suspended'),
	(13, 'C Clinic', '789 Oak', 'Rejected'),
	(14, 'D', '100 Flower', 'Verified'),
	(15, 'E', '200 Maple', 'Pending'),
	(16, 'F', '300 Cedar', 'Pending');

-- Dumping structure for table blood_donation_system.notification
CREATE TABLE IF NOT EXISTS `notification` (
  `notification_id` int unsigned NOT NULL AUTO_INCREMENT,
  `message` varchar(150) NOT NULL,
  `channel` varchar(15) NOT NULL,
  `status` varchar(15) NOT NULL,
  `sent_date` date NOT NULL,
  `donor_id` int unsigned NOT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `donor_id` (`donor_id`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.notification: ~3 rows (approximately)
DELETE FROM `notification`;
INSERT INTO `notification` (`notification_id`, `message`, `channel`, `status`, `sent_date`, `donor_id`) VALUES
	(1, 'To Chris Wilson: abc', 'Email', 'Sent', '2026-02-02', 1),
	(2, 'To Chris Wilson: abc', 'SMS', 'Sent', '2026-02-02', 1),
	(3, 'To Chris Wilson: abc', 'In-App', 'Sent', '2026-02-02', 1);

-- Dumping structure for table blood_donation_system.registrationrequest
CREATE TABLE IF NOT EXISTS `registrationrequest` (
  `request_id` int unsigned NOT NULL AUTO_INCREMENT,
  `hospital_id` int unsigned NOT NULL,
  `documents` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `submit_date` date NOT NULL,
  `rejection_reason` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `hospital_id` (`hospital_id`),
  CONSTRAINT `registrationrequest_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.registrationrequest: ~1 rows (approximately)
DELETE FROM `registrationrequest`;
INSERT INTO `registrationrequest` (`request_id`, `hospital_id`, `documents`, `status`, `submit_date`, `rejection_reason`) VALUES
	(1, 13, 'doc_link_13.pdf', 'Rejected', '2023-12-01', 'Invalid License'),
	(2, 13, 'doc_link_13.pdf', 'Rejected', '2023-12-01', 'Invalid License'),
	(3, 13, 'doc_link_13.pdf', 'Rejected', '2023-12-01', 'Invalid License'),
	(4, 14, 'doc_link_14.pdf', 'Approved', '2024-01-10', NULL),
	(5, 15, 'doc_link_15.pdf', 'Pending', '2024-01-12', NULL),
	(6, 16, 'doc_link_16.pdf', 'Pending', '2024-01-15', NULL);

-- Dumping structure for table blood_donation_system.report
CREATE TABLE IF NOT EXISTS `report` (
  `report_id` int unsigned NOT NULL AUTO_INCREMENT,
  `report_type` varchar(20) NOT NULL,
  `generated_by` int unsigned NOT NULL,
  `generated_date` date NOT NULL,
  `export_format` varchar(10) NOT NULL,
  PRIMARY KEY (`report_id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `report_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.report: ~0 rows (approximately)
DELETE FROM `report`;
INSERT INTO `report` (`report_id`, `report_type`, `generated_by`, `generated_date`, `export_format`) VALUES
	(1, 'Donation', 11, '2026-02-02', 'PDF'),
	(2, 'Donation', 11, '2026-02-02', 'PDF'),
	(3, 'Donation', 11, '2026-02-02', 'PDF'),
	(4, 'Donation', 11, '2026-02-02', 'PDF'),
	(5, 'Inventory Status', 11, '2026-02-02', 'PDF'),
	(6, 'Inventory Status', 11, '2026-02-02', 'PDF'),
	(7, 'Inventory Status', 11, '2026-02-02', 'PDF');

-- Dumping structure for table blood_donation_system.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` varchar(15) DEFAULT 'Active',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table blood_donation_system.user: ~20 rows (approximately)
DELETE FROM `user`;
INSERT INTO `user` (`user_id`, `name`, `email`, `password`, `role`, `status`) VALUES
	(1, 'John Doe', 'john.doe@example.com', 'pass123', 'Donor', 'Active'),
	(2, 'Jane Smith', 'jane.smith@example.com', 'pass123', 'Donor', 'Active'),
	(3, 'Michael Brown', 'michael.b@example.com', 'pass123', 'Donor', 'Active'),
	(4, 'Emily Davis', 'emily.d@example.com', 'pass123', 'Donor', 'Active'),
	(5, 'Chris Wilson', 'chris.w@example.com', 'pass123', 'Donor', 'Active'),
	(6, 'Alice Green', 'alice.g@example.com', 'pass123', 'Organizer', 'Active'),
	(7, 'Bob White', 'bob.w@example.com', 'pass123', 'Organizer', 'Active'),
	(8, 'Charlie Black', 'charlie.b@example.com', 'pass123', 'Organizer', 'Active'),
	(9, 'David Grey', 'david.g@example.com', 'pass123', 'Organizer', 'Active'),
	(10, 'Eve Blue', 'eve.b@example.com', 'pass123', 'Organizer', 'Active'),
	(11, 'A Hosp', 'a@hosp.com', 'pass123', 'Hospital', 'Active'),
	(12, 'B Hosp', 'b@hosp.com', 'pass123', 'Hospital', 'Active'),
	(13, 'C Hosp', 'c@hosp.com', 'pass123', 'Hospital', 'Pending'),
	(14, 'D Hosp', 'd@hosp.com', 'pass123', 'Hospital', 'Pending'),
	(15, 'E Hosp', 'e@hosp.com', 'pass123', 'Hospital', 'Pending'),
	(16, 'F Hosp', 'f@hosp.com', 'pass123', 'Hospital', 'Active'),
	(17, 'A1', 'admin1@sys.com', 'pass123', 'Admin', 'Active'),
	(18, 'A2', 'admin2@sys.com', 'pass123', 'Admin', 'Active'),
	(19, 'A3', 'admin3@sys.com', 'pass123', 'Admin', 'Active'),
	(20, 'A4', 'admin4@sys.com', '1', 'Admin', 'Active');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
