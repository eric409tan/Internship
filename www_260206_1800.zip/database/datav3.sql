-- datav3.sql
USE blood_donation_system;

-- Donors
INSERT INTO User (name, email, password, role, status) VALUES
('John', 'john@donor.com', 'pass123', 'Donor', 'Active'),
('Marry', 'marry@donor.com', 'pass123', 'Donor', 'Active'),
('Jeffrey', 'jeffrey@donor.com', 'pass123', 'Donor', 'Active'),
('Lee', 'lee@donor.com', 'pass123', 'Donor', 'Active'),
('Nave ', 'nave@donor.com', 'pass123', 'Donor', 'Active');

-- Organizers
INSERT INTO User (name, email, password, role, status) VALUES
('Dave', 'dave@test.org', 'pass123', 'Organizer', 'Active'),
('David', 'david@test.org', 'pass123', 'Organizer', 'Active'),
('Eve', 'eve@test.org', 'pass123', 'Organizer', 'Active'),
('Town', 'town@test.org', 'pass123', 'Organizer', 'Active'),
('Gist', 'gist@test.org', 'pass123', 'Organizer', 'Active');


-- Hospitals
INSERT INTO User (name, email, password, role, status) VALUES
('Hospital Kuala Lumpur', 'kl@hosp.com', 'pass123', 'Hospital', 'Active'),
('Hospital Serdang', 'serdang@hosp.com', 'pass123', 'Hospital', 'Active'),
('Hospital Cyberjaya', 'cyber@hosp.com', 'pass123', 'Hospital', 'Active'),
('Hospital Selangor', 'selangor@hosp.com', 'pass123', 'Hospital', 'Active'),
('Hospital Putrajaya', 'putrajaya@hosp.com', 'pass123', 'Hospital', 'Active');


-- Admins
INSERT INTO User (name, email, password, role, status) VALUES
('Admin A', 'admin.a@sys.com', 'pass123', 'Admin', 'Active'),
('Admin B', 'admin.b@sys.com', 'pass123', 'Admin', 'Active'),
('Admin C', 'admin.c@sys.com', 'pass123', 'Admin', 'Active'),
('Admin D', 'admin.d@sys.com', 'pass123', 'Admin', 'Active'),
('Admin E', 'admin.e@sys.com', 'pass123', 'Admin', 'Active');




INSERT INTO Donor (donor_id, blood_type, contact_number) VALUES
(1, 'A+', '0121111111'), (2, 'B+', '0121111112'),
(3, 'O+', '0121111163'), (4, 'AB+', '0121111164'),
(5, 'A-', '0121111165');


-- Organzier
INSERT INTO EventOrganizer (organizer_id, organization_name, verification_status) VALUES
(6, 'Dave Foundation', 'Verified'),
(7, 'David NGO', 'Verified'),
(8, 'Eve Org', 'Verified'),
(9, 'Town Event', 'Verified'),
(10, 'Gist Team', 'Verified');


-- Hospital
INSERT INTO Hospital (hospital_id, hospital_name, address, verification_status) VALUES
(11, 'Hospital Kuala Lumpur', '50000 Kuala Lumpur', 'Verified'),
(12, 'Hospital Serdang', '43000 Serdang', 'Verified'),
(13, 'Hospital Cyberjaya', '63000 Cyberjaya', 'Pending'),
(14, 'Hospital Selangor', '40000 Selangor', 'Pending'),
(15, 'Hospital Putrajaya', '62000 Putrajaya', 'Pending');


-- Event
INSERT INTO Event (event_name, event_date, event_time, venue, capacity, status, organizer_id, `desc`) VALUES
-- 2025: Starting from June, 2 Events per month (Completed)
('Event 25-06A', '2025-06-10', '09:00', 'Hall A', 100, 'Completed', 7, 'June Event A'),
('Event 25-06B', '2025-06-20', '09:00', 'Hall B', 100, 'Completed', 6, 'June Event B'),
('Event 25-07A', '2025-07-10', '09:00', 'Hall A', 100, 'Completed', 10, 'July Event A'),
('Event 25-07B', '2025-07-20', '09:00', 'Hall B', 100, 'Completed', 9, 'July Event B'),
('Event 25-08A', '2025-08-10', '09:00', 'Hall A', 100, 'Completed', 8, 'August Event A'),
('Event 25-08B', '2025-08-20', '09:00', 'Hall B', 100, 'Completed', 7, 'August Event B'),
('Event 25-09A', '2025-09-10', '09:00', 'Hall A', 100, 'Completed', 6, 'September Event A'),
('Event 25-09B', '2025-09-20', '09:00', 'Hall B', 100, 'Completed', 10, 'September Event B'),
('Event 25-10A', '2025-10-10', '09:00', 'Hall A', 100, 'Completed', 9, 'October Event A'),
('Event 25-10B', '2025-10-20', '09:00', 'Hall B', 100, 'Completed', 8, 'October Event B'),
('Event 25-11A', '2025-11-10', '09:00', 'Hall A', 100, 'Completed', 7, 'November Event A'),
('Event 25-11B', '2025-11-20', '09:00', 'Hall B', 100, 'Completed', 6, 'November Event B'),
('Event 25-12A', '2025-12-10', '09:00', 'Hall A', 100, 'Completed', 10, 'December Event A'),
('Event 25-12B', '2025-12-20', '09:00', 'Hall B', 100, 'Completed', 9, 'December Event B'),

-- 2026 January: 3 Events (Completed)
('Event 26-01A', '2026-01-05', '09:00', 'Hall C', 100, 'Completed', 8, 'Jan 26 Event A'),
('Event 26-01B', '2026-01-15', '09:00', 'Hall C', 100, 'Completed', 6, 'Jan 26 Event B'),
('Event 26-01C', '2026-01-25', '09:00', 'Hall C', 100, 'Completed', 10, 'Jan 26 Event C'),

-- 2026 February (Current Month): 2 Events (Upcoming)
('Event 26-02A', '2026-02-10', '09:00', 'Hall D', 100, 'Upcoming', 7, 'Feb 26 Event A'),
('Event 26-02B', '2026-02-20', '09:00', 'Hall D', 100, 'Upcoming', 9, 'Feb 26 Event B'),

-- 2026 March (Next Month): 3 Events (Upcoming)
('Event 26-03A', '2026-03-05', '09:00', 'Hall E', 100, 'Upcoming', 8, 'Mar 26 Event A'),
('Event 26-03B', '2026-03-15', '09:00', 'Hall E', 100, 'Upcoming', 6, 'Mar 26 Event B'),
('Event 26-03C', '2026-03-25', '09:00', 'Hall E', 100, 'Upcoming', 10, 'Mar 26 Event C');

-- ==========================================================
-- 6. TABLE: APPOINTMENT (60 rows)
-- Maps Donors 1-60 to Events (Auto-inc 1-60)
-- ==========================================================
INSERT INTO Appointment (donor_id, event_id, appointment_date, time_slot, status) VALUES
-- 2025 Appointments (Completed/Cancelled)
(1, 1, '2025-06-10', '09:00', 'Completed'), (4, 2, '2025-06-20', '09:00', 'Completed'),
(1, 3, '2025-07-10', '09:00', 'Completed'), (5, 4, '2025-07-20', '15:00', 'Completed'),
(1, 5, '2025-08-10', '09:00', 'Completed'), (2, 6, '2025-08-20', '10:00', 'Completed'),
(3, 7, '2025-09-10', '09:00', 'Completed'), (1, 8, '2025-09-20', '11:30', 'Completed'),
(4, 9, '2025-10-10', '09:00', 'Completed'), (1, 10, '2025-10-20', '09:00', 'Cancelled'),
(5, 11, '2025-11-10', '13:00', 'Completed'), (1, 12, '2025-11-20', '09:00', 'Completed'),
(2, 13, '2025-12-10', '09:00', 'Completed'), (1, 14, '2025-12-20', '10:00', 'Completed'),

-- 2026 Jan Appointments (Completed)
(1, 15, '2026-01-05', '09:00', 'Completed'), 
(3, 16, '2026-01-15', '11:00', 'Completed'), 
(1, 17, '2026-01-25', '14:00', 'Completed'),

-- 2026 Feb Appointments (Booked)
(1, 18, '2026-02-10', '09:00', 'Booked'), 
(4, 19, '2026-02-20', '10:30', 'Booked'),

-- 2026 March Appointments (Booked)
(1, 20, '2026-03-05', '09:00', 'Booked'), 
(5, 21, '2026-03-15', '11:00', 'Booked'), 
(1, 22, '2026-03-25', '15:00', 'Booked');

-- ==========================================================
-- 7. TABLE: BLOOD INVENTORY (60 rows)
-- Uses Hospital IDs 121-180
-- ==========================================================
INSERT INTO BloodInventory (hospital_id, blood_type, quantity, status) VALUES
-- Hospital 11 Inventory
(11, 'A+', 25, 'Normal'), (11, 'B+', 18, 'Normal'), (11, 'O+', 30, 'Normal'), (11, 'AB+', 12, 'Normal'),
(11, 'A-', 6, 'Low'), (11, 'B-', 4, 'Low'), (11, 'O-', 1, 'Critical'), (11, 'AB-', 5, 'Low'),

-- Hospital 12 Inventory
(12, 'A+', 20, 'Normal'), (12, 'B+', 22, 'Normal'), (12, 'O+', 15, 'Normal'), (12, 'AB+', 10, 'Normal'),
(12, 'A-', 3, 'Low'), (12, 'B-', 7, 'Normal'), (12, 'O-', 8, 'Normal'), (12, 'AB-', 2, 'Critical'),

-- Hospital 13 Inventory
(13, 'A+', 15, 'Normal'), (13, 'B+', 2, 'Critical'), (13, 'O+', 20, 'Normal'), (13, 'AB+', 14, 'Normal'),
(13, 'A-', 1, 'Critical'), (13, 'B-', 8, 'Normal'), (13, 'O-', 5, 'Low'), (13, 'AB-', 6, 'Low'),

-- Hospital 14 Inventory
(14, 'A+', 2, 'Critical'), (14, 'B+', 19, 'Normal'), (14, 'O+', 3, 'Low'), (14, 'AB+', 11, 'Normal'),
(14, 'A-', 9, 'Normal'), (14, 'B-', 10, 'Normal'), (14, 'O-', 12, 'Normal'), (14, 'AB-', 4, 'Low'),

-- Hospital 15 Inventory
(15, 'A+', 18, 'Normal'), (15, 'B+', 15, 'Normal'), (15, 'O+', 1, 'Critical'), (15, 'AB+', 9, 'Normal'),
(15, 'A-', 4, 'Low'), (15, 'B-', 3, 'Low'), (15, 'O-', 2, 'Critical'), (15, 'AB-', 12, 'Normal');


-- ==========================================================
-- 8. TABLE: REGISTRATION REQUEST (60 rows)
-- Uses Hospital IDs 121-180
-- ==========================================================
INSERT INTO RegistrationRequest (hospital_id, documents, status, submit_date, rejection_reason) VALUES
-- Hospital 13-15: All Pending for verification
(13, 'hospital_13_license.pdf', 'Pending', '2026-02-01', NULL),
(14, 'hospital_14_cert.pdf', 'Pending', '2026-02-02', NULL),
(15, 'hospital_15_docs.pdf', 'Pending', '2026-02-03', NULL);


-- ==========================================================
-- 9. TABLE: NOTIFICATION (60 rows)
-- Uses Donor IDs 1-60
-- ==========================================================
INSERT INTO Notification (message, channel, status, sent_date, user_id) VALUES
-- Donor 1 (The Most Booked Donor)
('Your blood donation appointment is confirmed for Feb 10.', 'App', 'Read', '2026-02-01', 1),
('Reminder: Drink plenty of water before your donation tomorrow.', 'SMS', 'Sent', '2026-02-09', 1),
('Thank you for your donation! Your blood has been processed.', 'Email', 'Sent', '2026-01-26', 1),

-- Donor 2
('New blood drive event near you: Event 26-02B.', 'App', 'Read', '2026-02-05', 2),
('Your appointment for March has been successfully booked.', 'Email', 'Sent', '2026-02-06', 2),
('Donation tip: Eat an iron-rich meal today.', 'SMS', 'Sent', '2026-01-15', 2),

-- Donor 3
('Appointment update: Your venue has been moved to Hall C.', 'App', 'Read', '2026-01-04', 3),
('Security alert: New login detected on your account.', 'Email', 'Sent', '2026-02-02', 3),
('Quick survey: How was your donation experience on Jan 15?', 'SMS', 'Sent', '2026-01-16', 3),

-- Donor 4
('Your appointment for Event 25-06B was cancelled.', 'Email', 'Sent', '2025-06-18', 4),
('Flash alert: O- blood type is urgently needed at Hospital 11.', 'App', 'Read', '2026-02-06', 4),
('Happy Birthday! Visit us this month for a special donor badge.', 'SMS', 'Sent', '2026-02-01', 4),

-- Donor 5
('Your next eligible donation date is March 15.', 'App', 'Read', '2026-01-20', 5),
('Booking confirmed for Event 26-03B.', 'Email', 'Sent', '2026-02-06', 5),
('Important: Please bring your ID for your donation tomorrow.', 'SMS', 'Sent', '2025-11-09', 5),

-- Hospital 11
('URGENT: O- blood inventory has reached CRITICAL level (1 unit).', 'App', 'Read', '2026-02-06', 11),
('Monthly report for January 2026 is now available.', 'Email', 'Sent', '2026-02-01', 11),
('System Update: New donor verification features are live.', 'App', 'Read', '2026-01-15', 11),

-- Hospital 12
('CRITICAL ALERT: AB- blood stock is dangerously low.', 'App', 'Read', '2026-02-06', 12),
('Staffing reminder: Ensure 2 nurses are assigned to the Feb 10 event.', 'Email', 'Sent', '2026-02-05', 12),
('Inventory sync completed successfully.', 'SMS', 'Sent', '2026-02-04', 12),

-- Hospital 13 (Pending Registration)
('Registration Request Received: Documents are under review.', 'Email', 'Sent', '2026-02-01', 13),
('Action Required: Please verify your hospital license expiry date.', 'App', 'Read', '2026-02-03', 13),
('Reminder: Complete your hospital profile to unlock all features.', 'SMS', 'Sent', '2026-02-05', 13),

-- Hospital 14 (Pending Registration)
('Registration status: Pending. Expected review within 3 days.', 'App', 'Read', '2026-02-02', 14),
('Welcome! Check our guide on managing blood inventory.', 'Email', 'Sent', '2026-02-02', 14),
('Security alert: Admin password changed.', 'SMS', 'Sent', '2026-02-04', 14),

-- Hospital 15 (Pending Registration)
('URGENT: O+ and O- inventory is CRITICAL.', 'App', 'Read', '2026-02-06', 15),
('Document upload successful: hospital_15_docs.pdf.', 'Email', 'Sent', '2026-02-03', 15),
('New message from System Admin regarding your registration.', 'SMS', 'Sent', '2026-02-05', 15);

-- ==========================================================
-- 10. TABLE: REPORT (50 rows)
-- Uses Admin IDs 181-230
-- ==========================================================
INSERT INTO Report (report_type, generated_by, generated_date, export_format) VALUES
-- Admin Reports (Full System Overviews)
('Annual Report 2025/P1', 1, '2026-01-31', 'PDF'),
('Annual Report 2025/P2', 1, '2026-02-01', 'PDF'),

-- Hospital 11 Reports (Inventory & Internal Metrics)
('Blood Report 1', 11, '2026-01-31', 'PDF'),
('Blood Report 2', 11, '2026-02-05', 'PDF');